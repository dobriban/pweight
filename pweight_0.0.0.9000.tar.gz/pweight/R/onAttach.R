.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Welcome to the pweight package")
}
